// Client side C/C++ program to demonstrate Socket programming
#include <time.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#define PORT 8080

int main(int argc, char const *argv[])
{
	int sock = 0;
	struct sockaddr_in serv_addr;
	char *hello = "Hellofromclient,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1,";
	char buffer[1024] = {0};

	// create TCP socket
	// AF_INET - Protocol (AF_INET is for IPv4)
	// SOCK_STREAM type - type of socket (SOCK_STREAM - for TCP, SOCK_DGRAM - from UDP)
	// protocol - protocol transport layer - 0 to default
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("\n Socket creation error \n");
		return -1;
	}

	// make the socket struct contain the protocol and the PORT of the server he will connect to
	serv_addr.sin_family = AF_INET;

    // htons() // host to network short
    // htonl() // host to network long
    // ntohs() // network to host short
    // ntohl() // network to host long
	serv_addr.sin_port = htons(PORT);
	
	// convert IPv4 and IPv6 addresses from text to binary form
	if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0) {
		printf("\nInvalid address/ Address not supported \n");
		return -1;
	}

	// connect
	// sock - the sockid - the return value of the function socket()
	// (struct sockaddr *)&serv_addr, - a pointer to the socket struct
	// sizeof(serv_addr)) - the size of serv_addr (struct)
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
	{
		printf("\nConnection Failed \n");
		return -1;
	}
	
	FILE *fp;
    long lSize;
    char *buffer2;

    fp = fopen ( "sen.c" , "rb" );
    if( !fp ) perror("blah.txt"),exit(1);

    fseek( fp , 0L , SEEK_END);
    lSize = ftell( fp );
    rewind( fp );

    /* allocate memory for entire content */
    buffer2 = calloc( 1, lSize+1 );
    if( !buffer2 ) fclose(fp),fputs("memory alloc fails",stderr),exit(1);

    /* copy the file into the buffer */
    if( 1!=fread( buffer2 , lSize, 1 , fp) )
    fclose(fp),free(buffer2),fputs("entire read fails",stderr),exit(1);

    /* do your work here, buffer is a string contains the whole text */

	char buf[256];
	socklen_t len;
	len = sizeof(buf); 
	if(getsockopt(sock, IPPROTO_TCP, TCP_CONGESTION, buf, &len) != 0) {
		perror("getsockopt");
		return -1;
	}

	printf("Current: %s\n", buf);
	for(int i = 0;i < 5; i++) {
		send(sock, hello, strlen(hello), 0);
		printf("Hello message sent\n");
		sleep(6);
	}
	
	
	//// now  change cc algorithm
    strcpy(buf, "reno"); 
	len = strlen(buf);
	if(setsockopt(sock, IPPROTO_TCP, TCP_CONGESTION, buf, len) != 0)
	{
		perror("setsockopt"); 
		return 0;
	}
	printf("New: %s\n", buf);
	sleep(3);
	for(int i = 0; i < 5; i++) {

	    // sending a socket to measure
	    // sock - the sock id
	    // hello - the massage to send
	    // strlen(hello) - the len of the message
	    // flag - by default be 0
		send(sock , hello , strlen(hello) , 0 );
		printf("Hello message sent\n");
		sleep(3);
	}
	//fclose(fp);
	//free(buffer2);
	return 0;
}
