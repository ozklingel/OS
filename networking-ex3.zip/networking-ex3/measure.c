// Server side C/C++ program to demonstrate Socket programming
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h> 
#define PORT 8080
int main(int argc, char const *argv[])
{
	int server_fd, file_de, valread;
	struct sockaddr_in address;
	int opt = 1;
	int addrlen = sizeof(address);
	char buffer[711] = {0};
	char *hello = "Hello from server";
	
	// Creating socket file descriptor
	if((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// for use again the socket
	// forcefully attaching socket to the port 8080
	if(setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

	// change address struct properties
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	// forcefully attaching socket to the port 8080
	if(bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

    // for make the server connect to client and wait to answer
	if(listen(server_fd, 3) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}

	printf("listening...: \n");

	// request for reconnecting to client
	if((file_de = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0) {
		perror("accept");
		exit(EXIT_FAILURE);
	}

	char buf[256];
	socklen_t len;
	len = sizeof(buf);
	if(getsockopt(server_fd, IPPROTO_TCP, TCP_CONGESTION, buf, &len) != 0) { 
		perror("getsockopt");
		return -1;
	}

	printf("Current: %s\n", buf); 

	clock_t start, end;
    double cpu_time_used;
	double t [5] ={0,0,0,0,0};

	for(int i = 0; i < 5; i++) {
	    start = clock();
		valread = read( file_de , buffer, 711);
		//printf(buffer);
		end = clock();
		cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
		printf("\ncpu_time_used for this file: %f\n",cpu_time_used);
		t[i]=cpu_time_used;
 
		start = clock();
		//sleep();
	}
	printf("cpu_time_used mean: %f\n",(t[1]+t[2]+t[3]+t[4]+t[0])/5);
	////now  change cc algorithm
    strcpy(buf, "reno"); 
	len = strlen(buf);
	if(setsockopt(server_fd, IPPROTO_TCP, TCP_CONGESTION, buf, len) != 0) {
		perror("setsockopt"); 
		return 0;
	}
	
	printf("New: %s\n", buf);
	for(int i = 0;i < 5; i++) {
		start = clock();
		valread = read( file_de , buffer, 711);
		//printf(buffer);
		end = clock();
		cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

		printf("\ncpu_time_used for this file: %f\n",cpu_time_used);
		t[i]=cpu_time_used;
		
		start = clock();
		
		//sleep(3);
	}
  	printf("cpu_time_used mean: %f\n",(t[1]+t[2]+t[3]+t[4]+t[0])/5);
	return 0;
}
